python main.py --SAVE_NUM 821 --SEED 1111 --LR_RATE 1.3e-5
python main.py --SAVE_NUM 822 --SEED 1112 --LR_RATE 1.3e-5 
python main.py --SAVE_NUM 823 --SEED 1113 --LR_RATE 1.3e-5
python main.py --SAVE_NUM 824 --SEED 1114 --LR_RATE 1.3e-5 
python main.py --SAVE_NUM 825 --SEED 1115 --LR_RATE 1.3e-5
python main.py --SAVE_NUM 826 --SEED 1116 --LR_RATE 1.3e-5
python main.py --SAVE_NUM 827 --SEED 1117 --LR_RATE 1.3e-5 
python main.py --SAVE_NUM 828 --SEED 1118 --LR_RATE 1.3e-5
python main.py --SAVE_NUM 829 --SEED 1119 --LR_RATE 1.3e-5 
python main.py --SAVE_NUM 830 --SEED 1120 --LR_RATE 1.3e-5

python main.py --SAVE_NUM 821 --SEED 1111 --DATASET 'harm' --FIX_LAYERS 0
python main.py --SAVE_NUM 822 --SEED 1112 --DATASET 'harm' --FIX_LAYERS 0
python main.py --SAVE_NUM 823 --SEED 1113 --DATASET 'harm' --FIX_LAYERS 0
python main.py --SAVE_NUM 824 --SEED 1114 --DATASET 'harm' --FIX_LAYERS 0
python main.py --SAVE_NUM 825 --SEED 1115 --DATASET 'harm' --FIX_LAYERS 0
python main.py --SAVE_NUM 826 --SEED 1116 --DATASET 'harm' --FIX_LAYERS 0
python main.py --SAVE_NUM 827 --SEED 1117 --DATASET 'harm' --FIX_LAYERS 0
python main.py --SAVE_NUM 828 --SEED 1118 --DATASET 'harm' --FIX_LAYERS 0
python main.py --SAVE_NUM 829 --SEED 1119 --DATASET 'harm' --FIX_LAYERS 0
python main.py --SAVE_NUM 830 --SEED 1120 --DATASET 'harm' --FIX_LAYERS 0