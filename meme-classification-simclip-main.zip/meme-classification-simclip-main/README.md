# SimCLIP
Code for the SimCLIP method. The code is disorganized, but feel free to explore it for reproducibility of experiments.

Not yet published.
