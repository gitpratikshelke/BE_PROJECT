#!/usr/bin/env bash

echo "For installation instructions visit https://github.com/hardikvasa/google-images-download"

googleimagesdownload -k "racist meme" -l 1000
googleimagesdownload -k "muslim meme" -l 1000
googleimagesdownload -k "jew meme" -l 1000
